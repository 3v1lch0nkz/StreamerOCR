StreamerOCR Installation Guide

1. Install Tesseract OCR:
   - Download Tesseract OCR installer from: https://github.com/UB-Mannheim/tesseract/wiki
   - Run the installer
   - IMPORTANT: During installation, check "Add to system PATH"
   - Default install location: C:\Program Files\Tesseract-OCR

2. Run StreamerOCR:
   - Double-click StreamerOCR.exe
   - If Windows SmartScreen appears, click "More info" and then "Run anyway"

Keyboard Shortcuts:
- Alt + Shift + Space: Process selected region
- Alt + Shift + M: Select new region
- Alt + Shift + N: Exit application

Troubleshooting:
- If you get an error about Tesseract not being found, ensure it's properly installed and added to PATH
- Try restarting your computer after installing Tesseract
- Make sure you have Windows 10 or later

For support, visit: [Your GitHub Repository URL] 